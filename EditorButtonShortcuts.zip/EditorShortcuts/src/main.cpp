#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/loader/SettingV3.hpp>
#include <Geode/utils/Keyboard.hpp>

using namespace geode::prelude;

namespace {
    using ButtonMember = CCMenuItemSpriteExtra* EditorUI::*;

    struct ShortcutAction {
        char const* settingKey;
        ButtonMember member;
        char const* nodeID;
        void (*fallback)(EditorUI*);
        bool repeatable;
        bool duringPlaytest;
    };

    std::vector<ShortcutAction> const& getActions() {
        static std::vector<ShortcutAction> const actions = {
            { "edit-object",     &EditorUI::m_editObjectBtn,    nullptr, nullptr, false, false },
            { "edit-group",      &EditorUI::m_editGroupBtn,     nullptr, nullptr, false, false },
            { "deselect",        &EditorUI::m_deselectBtn,      nullptr, nullptr, false, false },
            { "edit-special",    &EditorUI::m_editSpecialBtn,   nullptr, nullptr, false, false },
            { "edit-hsv",        &EditorUI::m_editHSVBtn,       nullptr, nullptr, false, false },
            { "copy-paste",      &EditorUI::m_copyPasteBtn,     nullptr, nullptr, false, false },
            { "copy",            &EditorUI::m_copyBtn,          nullptr, nullptr, false, false },
            { "paste",           &EditorUI::m_pasteBtn,         nullptr, nullptr, false, false },
            { "copy-values",     &EditorUI::m_copyValuesBtn,    nullptr, nullptr, false, false },
            { "paste-state",     &EditorUI::m_pasteStateBtn,    nullptr, nullptr, false, false },
            { "paste-color",     &EditorUI::m_pasteColorBtn,    nullptr, nullptr, false, false },
            { "go-to-layer",     &EditorUI::m_goToLayerBtn,     nullptr, nullptr, false, false },
            { "link",            &EditorUI::m_linkBtn,          nullptr, nullptr, false, false },
            { "unlink",          &EditorUI::m_unlinkBtn,        nullptr, nullptr, false, false },
            { "swipe",           &EditorUI::m_swipeBtn,         nullptr, nullptr, false, false },
            { "rotate",          &EditorUI::m_rotateBtn,        nullptr, nullptr, false, false },
            { "free-move",       &EditorUI::m_freeMoveBtn,      nullptr, nullptr, false, false },
            { "snap",            &EditorUI::m_snapBtn,          nullptr, nullptr, false, false },
            { "playtest",        &EditorUI::m_playtestBtn,      nullptr, nullptr, false, true  },
            { "stop-playtest",   &EditorUI::m_playtestStopBtn,  nullptr, nullptr, false, true  },
            { "music",           &EditorUI::m_playbackBtn,      nullptr, nullptr, false, false },
            { "zoom-in",         nullptr, "zoom-in-button",  [](EditorUI* ui) { ui->zoomIn(nullptr); },  true, false },
            { "zoom-out",        nullptr, "zoom-out-button", [](EditorUI* ui) { ui->zoomOut(nullptr); }, true, false },
            { "next-layer",      &EditorUI::m_layerNextBtn,     nullptr, nullptr, true,  false },
            { "prev-layer",      &EditorUI::m_layerPrevBtn,     nullptr, nullptr, true,  false },
            { "all-layers",      &EditorUI::m_goToBaseBtn,      nullptr, nullptr, false, false },
            { "undo",            &EditorUI::m_undoBtn,          nullptr, nullptr, true,  false },
            { "redo",            &EditorUI::m_redoBtn,          nullptr, nullptr, true,  false },
            { "delete-selected", &EditorUI::m_trashBtn,         nullptr, nullptr, false, false },
            { "build-mode",      &EditorUI::m_buildModeBtn,     nullptr, nullptr, false, false },
            { "edit-mode",       &EditorUI::m_editModeBtn,      nullptr, nullptr, false, false },
            { "delete-mode",     &EditorUI::m_deleteModeBtn,    nullptr, nullptr, false, false },
        };
        return actions;
    }

    CCMenuItemSpriteExtra* getButton(EditorUI* ui, ShortcutAction const& action) {
        if (action.member) {
            return ui->*(action.member);
        }
        if (action.nodeID) {
            return typeinfo_cast<CCMenuItemSpriteExtra*>(ui->getChildByIDRecursive(action.nodeID));
        }
        return nullptr;
    }

    bool isShown(CCNode* node, CCNode* root) {
        for (auto current = node; current && current != root; current = current->getParent()) {
            if (!current->isVisible()) {
                return false;
            }
        }
        return root->isVisible();
    }

    bool isEditorFocused(EditorUI* ui) {
        auto editor = ui->m_editorLayer;
        auto scene = CCDirector::get()->getRunningScene();
        if (!editor || !scene || editor->getParent() != scene) {
            return false;
        }
        for (auto child : CCArrayExt<CCNode*>(scene->getChildren())) {
            if (child == editor) {
                continue;
            }
            if (typeinfo_cast<FLAlertLayer*>(child) || typeinfo_cast<CCBlockLayer*>(child)) {
                return false;
            }
        }
        return true;
    }

    bool runAction(size_t index, bool down, bool repeat) {
        if (!down) {
            return false;
        }
        auto mod = Mod::get();
        if (!mod->getSettingValue<bool>("enabled")) {
            return false;
        }
        auto ui = EditorUI::get();
        if (!ui || !isEditorFocused(ui)) {
            return false;
        }

        auto const& action = getActions()[index];
        bool playing = ui->m_editorLayer->m_playbackMode != PlaybackMode::Not;
        if (playing && !action.duringPlaytest) {
            return false;
        }

        bool block = mod->getSettingValue<bool>("block-vanilla");
        if (repeat && !action.repeatable) {
            return block;
        }

        if (auto button = getButton(ui, action)) {
            if (!button->isEnabled() || !isShown(button, ui)) {
                return false;
            }
            button->activate();
            return block;
        }
        if (action.fallback) {
            action.fallback(ui);
            return block;
        }
        return false;
    }

    void placeLabel(CCLabelBMFont* label, CCSize const& size, std::string const& position) {
        float pad = 2.f;
        if (position == "Bottom Left") {
            label->setAnchorPoint({ 0.f, 0.f });
            label->setPosition({ pad, pad });
        }
        else if (position == "Top Right") {
            label->setAnchorPoint({ 1.f, 1.f });
            label->setPosition({ size.width - pad, size.height - pad });
        }
        else if (position == "Top Left") {
            label->setAnchorPoint({ 0.f, 1.f });
            label->setPosition({ pad, size.height - pad });
        }
        else if (position == "Center") {
            label->setAnchorPoint({ 0.5f, 0.5f });
            label->setPosition({ size.width / 2.f, size.height / 2.f });
        }
        else {
            label->setAnchorPoint({ 1.f, 0.f });
            label->setPosition({ size.width - pad, pad });
        }
    }

    void refreshLabels(EditorUI* ui) {
        if (!ui) {
            return;
        }
        auto mod = Mod::get();
        bool show = mod->getSettingValue<bool>("enabled") && mod->getSettingValue<bool>("show-labels");
        auto position = mod->getSettingValue<std::string>("label-position");
        auto scale = static_cast<float>(mod->getSettingValue<double>("label-scale"));
        auto opacity = static_cast<GLubyte>(std::clamp<int64_t>(mod->getSettingValue<int64_t>("label-opacity"), 0, 255));
        auto color = mod->getSettingValue<ccColor3B>("label-color");

        for (auto const& action : getActions()) {
            auto button = getButton(ui, action);
            if (!button) {
                continue;
            }
            if (auto old = button->getChildByID("shortcut-label"_spr)) {
                old->removeFromParent();
            }
            if (!show) {
                continue;
            }

            auto binds = mod->getSettingValue<std::vector<Keybind>>(action.settingKey);
            if (binds.empty() || binds.front().key == KEY_None) {
                continue;
            }

            auto text = binds.front().toString();
            auto label = CCLabelBMFont::create(text.c_str(), "bigFont.fnt");
            label->setID("shortcut-label"_spr);

            auto size = button->getContentSize();
            label->limitLabelWidth(std::max(size.width - 4.f, 8.f), scale, 0.05f);
            label->setOpacity(opacity);
            label->setColor(color);
            placeLabel(label, size, position);

            button->addChild(label, 100);
        }
    }
}

class $modify(ShortcutEditorUI, EditorUI) {
    bool init(LevelEditorLayer* editorLayer) {
        if (!EditorUI::init(editorLayer)) {
            return false;
        }
        Ref<EditorUI> self = this;
        queueInMainThread([self] {
            refreshLabels(self);
        });
        return true;
    }
};

$on_mod(Loaded) {
    auto const& actions = getActions();
    for (size_t i = 0; i < actions.size(); ++i) {
        listenForKeybindSettingPresses(actions[i].settingKey, [i](Keybind const&, bool down, bool repeat, double) -> bool {
            return runAction(i, down, repeat);
        });
    }

    listenForAllSettingChanges([](std::string_view, std::shared_ptr<SettingV3>) {
        if (auto ui = EditorUI::get()) {
            refreshLabels(ui);
        }
    });
}
